@extends('layouts.master')

@section('content')
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Tambah Barang</h2>
		<ol class="breadcrumb">
			<li>
				<a href="{{route('home')}}">Home</a>
			</li>
			<li>
				<a href="{{route('products.index')}}">Barang</a>
			</li>
			<li class="active">
				<strong>Tambah Barang</strong>
			</li>
		</ol>
	</div>
	<div class="col-lg-2">
	</div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="ibox float-e-margins">
		<div class="ibox-title">
			<h5>Tambah Data Barang</h5>
			<div class="ibox-tools">
				<a class="collapse-link">
					<i class="fa fa-chevron-up"></i>
				</a>
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">
					<i class="fa fa-wrench"></i>
				</a>
				<ul class="dropdown-menu dropdown-user">
					<li><a href="#">Config option 1</a>
					</li>
					<li><a href="#">Config option 2</a>
					</li>
				</ul>
				<a class="close-link">
					<i class="fa fa-times"></i>
				</a>
			</div>
		</div>
		<div class="ibox-content">
			<form method="get" class="form-horizontal">
				<div class="form-group"><label class="col-sm-2 control-label">Nama</label>
					<div class="col-sm-10"><input type="text" class="form-control"></div>
				</div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-sm-2 control-label">Kategori</label>
					<div class="col-sm-10"><select class="form-control m-b" name="account">
						<option>option 1</option>
						<option>option 2</option>
						<option>option 3</option>
						<option>option 4</option>
					</select>
				</div>
			</div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-sm-2 control-label">Merek</label>
					<div class="col-sm-10"><select class="form-control m-b" name="account">
						<option>option 1</option>
						<option>option 2</option>
						<option>option 3</option>
						<option>option 4</option>
					</select>
				</div></div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-sm-2 control-label">Satuan</label>
					<div class="col-sm-10"><select class="form-control m-b" name="account">
						<option>option 1</option>
						<option>option 2</option>
						<option>option 3</option>
						<option>option 4</option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-2 control-label">Column sizing</label>

                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-md-2"><label class="col-sm-2 control-label">Column sizing</label><input type="text" placeholder=".col-md-2" class="form-control"></div>
                        <div class="col-md-3"><label class="col-sm-2 control-label">Column sizing</label><input type="text" placeholder=".col-md-3" class="form-control"></div>
                        <div class="col-md-4"><label class="col-sm-2 control-label">Column sizing</label><input type="text" placeholder=".col-md-4" class="form-control"></div>
                    </div>
                </div>
            </div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-sm-2 control-label">Kategori</label>
					<div class="col-sm-10"><input type="text" class="form-control"></div>
				</div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-sm-2 control-label">Merek</label>
					<div class="col-sm-10"><input type="text" placeholder="placeholder" class="form-control"></div>
				</div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-lg-2 control-label">Satuan</label>
					<div class="col-lg-10"><input type="text" disabled="" placeholder="Disabled input here..." class="form-control"></div>
				</div>
				<div class="hr-line-dashed"></div>
				<div class="form-group"><label class="col-lg-2 control-label">Static control</label>
					<div class="col-lg-10"><p class="form-control-static">email@example.com</p></div>
				</div>
				
			
			<div class="hr-line-dashed"></div>
			<div class="form-group">
				<div class="col-sm-4 col-sm-offset-2">
					<a href="{{route('products.index')}}" class="btn btn-danger btn-sm">Batal</a>
					<button class="btn btn-primary btn-sm" type="submit">Simpan</button>
				</div>
			</div>
		</form>
	</div>
</div>
</div>
@endsection
