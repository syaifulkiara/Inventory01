@extends('layouts.app')

@section('content')
<div class="cards">
	<div class="row row-sm mg-t-20">
		@foreach($products as $item)
		<div class="col-lg-3 mb-4">
			<div class="card card-block bd-0 shadow-base pd-20">
				<center><a href="{{route('main.detail', $item->slug)}}"><img src="{{asset($item->images)}}" class="img-fluid" alt=""></a></center>
				<div class="d-flex justify-content-between align-items-center mg-t-20">
					<div>
						<h6 class="tx-14 tx-normal mg-b-2"><a href="{{route('main.detail', $item->slug)}}" class="tx-inverse"><strong>{{$item->name}}</strong></a></h6>
						<span class="tx-12">Brand : {{ $item->brand->name }}</span>
					</div>
					<div class="tx-right">
						<span class="tx-warning d-block">
							<i class="icon ion-star"></i>
							<i class="icon ion-star"></i>
							<i class="icon ion-star"></i>
							<i class="icon ion-star"></i>
							<i class="icon ion-star tx-gray-lighter"></i>
						</span>
						<span class="tx-12">Tersedia ( {{$item->stock}} )</span>
					</div>
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>
<div class="ht-80 bd d-flex align-items-center justify-content-center">
	<ul class="pagination pagination-basic pagination-circle mg-b-0">
		{!! $products->links() !!}
	</ul>
</div>
@endsection